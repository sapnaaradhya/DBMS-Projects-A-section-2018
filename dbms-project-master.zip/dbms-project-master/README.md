# dbms-project
USN : 1MV17CS400,1MV17CS414
NAME : AMULYA.M, PRIYANKA.M
PROJECT NAME: MOBILE ACCESSORIES DATABASE MANAGEMENT SYSTEM
DESCRIPTION :
     The software will help the customer to find the different mobiles and their different parts easily.
     It is designed in such a way that one can veiw all the mobiles and their different parts from any place through online.
